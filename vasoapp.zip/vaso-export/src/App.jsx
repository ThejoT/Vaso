import { VasoProvider, useVaso } from "./context/VasoContext";
import BottomNav from "./components/BottomNav";
import CrisisOverlay from "./components/CrisisOverlay";
import Monitor from "./tabs/Monitor";
import Crisis from "./tabs/Crisis";
import Card from "./tabs/Card";
import Care from "./tabs/Care";
import Log from "./tabs/Log";

const TAB_COMPONENTS = {
  monitor: Monitor,
  crisis: Crisis,
  card: Card,
  care: Care,
  log: Log,
};

function AppShell() {
  const { tab } = useVaso();
  const Screen = TAB_COMPONENTS[tab] ?? Monitor;

  return (
    <div className="min-h-screen bg-navy-950 flex justify-center">
      <div className="w-full max-w-[430px] min-h-screen bg-navy-950 flex flex-col relative">
        <header className="px-4 pt-5 pb-3 flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-crimson-600 flex items-center justify-center font-black text-white text-sm">
            V
          </div>
          <span className="font-extrabold text-white tracking-tight text-lg">Vaso</span>
        </header>

        <main className="flex-1 overflow-y-auto px-4">
          <Screen />
        </main>

        <BottomNav />
        <CrisisOverlay />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <VasoProvider>
      <AppShell />
    </VasoProvider>
  );
}
