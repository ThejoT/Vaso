import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { initialLog } from "../data/mock";

const VasoContext = createContext(null);

const BASELINE = { spo2: 97, hr: 78, temp: 98.6, hrv: 58 };
const CRISIS_PEAK = { spo2: 89, hr: 128, temp: 101.4, hrv: 23 };

export const THRESHOLDS = {
  spo2: { red: 92, warn: 95 },
  hr: { red: 110, warn: 100 },
  temp: { red: 100.4, warn: 99.5 },
  hrv: { red: 30, warn: 40 },
};

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function jitter(range) {
  return (Math.random() - 0.5) * 2 * range;
}

function seedHistory(value) {
  return new Array(20).fill(null).map(() => value + jitter(0.15));
}

const CASCADE_STEPS = [
  { key: "ayers", text: "Dr. Ayers notified" },
  { key: "contact", text: "Emergency contact Denise Johnson notified" },
  { key: "card", text: "Care card unlocked" },
];

export function VasoProvider({ children }) {
  const [tab, setTab] = useState("monitor");

  const [vitals, setVitals] = useState({ ...BASELINE });
  const [history, setHistory] = useState({
    spo2: seedHistory(BASELINE.spo2),
    hr: seedHistory(BASELINE.hr),
    temp: seedHistory(BASELINE.temp),
    hrv: seedHistory(BASELINE.hrv),
  });

  // idle | ramping | alerting | cascading | recovering
  const [crisisPhase, setCrisisPhase] = useState("idle");
  const [countdown, setCountdown] = useState(15);
  const [cascadeDone, setCascadeDone] = useState([]);
  const [crisisEverTriggered, setCrisisEverTriggered] = useState(false);
  const [deviceConnected] = useState(true);

  const [log, setLog] = useState(initialLog);
  const [actionFeedback, setActionFeedback] = useState(null);

  const phaseRef = useRef(crisisPhase);
  phaseRef.current = crisisPhase;

  const pushReading = useCallback((next) => {
    setVitals(next);
    setHistory((h) => ({
      spo2: [...h.spo2.slice(-19), next.spo2],
      hr: [...h.hr.slice(-19), next.hr],
      temp: [...h.temp.slice(-19), next.temp],
      hrv: [...h.hrv.slice(-19), next.hrv],
    }));
  }, []);

  // Baseline idle drift
  useEffect(() => {
    if (crisisPhase !== "idle") return undefined;
    const id = setInterval(() => {
      setVitals((v) => {
        const next = {
          spo2: clamp(v.spo2 + jitter(0.3), 95, 98),
          hr: clamp(v.hr + jitter(2), 70, 86),
          temp: clamp(v.temp + jitter(0.08), 98.2, 98.9),
          hrv: clamp(v.hrv + jitter(2.5), 50, 65),
        };
        setHistory((h) => ({
          spo2: [...h.spo2.slice(-19), next.spo2],
          hr: [...h.hr.slice(-19), next.hr],
          temp: [...h.temp.slice(-19), next.temp],
          hrv: [...h.hrv.slice(-19), next.hrv],
        }));
        return next;
      });
    }, 2000);
    return () => clearInterval(id);
  }, [crisisPhase]);

  // Ramp up into crisis over ~8s
  useEffect(() => {
    if (crisisPhase !== "ramping") return undefined;
    const totalSteps = 20;
    const stepMs = 400;
    const start = { ...vitals };
    let step = 0;
    const id = setInterval(() => {
      step += 1;
      const t = clamp(step / totalSteps, 0, 1);
      const eased = Math.pow(t, 1.3);
      const next = {
        spo2: clamp(start.spo2 + (CRISIS_PEAK.spo2 - start.spo2) * eased + jitter(0.2), 85, 100),
        hr: clamp(start.hr + (CRISIS_PEAK.hr - start.hr) * eased + jitter(1.5), 60, 160),
        temp: clamp(start.temp + (CRISIS_PEAK.temp - start.temp) * eased + jitter(0.05), 97, 103),
        hrv: clamp(start.hrv + (CRISIS_PEAK.hrv - start.hrv) * eased + jitter(1.5), 15, 70),
      };
      pushReading(next);
      if (step >= totalSteps) {
        clearInterval(id);
        setCrisisPhase("alerting");
      }
    }, stepMs);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [crisisPhase]);

  // Small live flicker while alert overlay is up
  useEffect(() => {
    if (crisisPhase !== "alerting") return undefined;
    const id = setInterval(() => {
      setVitals((v) => {
        const next = {
          spo2: clamp(v.spo2 + jitter(0.25), 86, 91),
          hr: clamp(v.hr + jitter(2), 120, 134),
          temp: clamp(v.temp + jitter(0.05), 100.8, 101.8),
          hrv: clamp(v.hrv + jitter(1.5), 18, 28),
        };
        setHistory((h) => ({
          spo2: [...h.spo2.slice(-19), next.spo2],
          hr: [...h.hr.slice(-19), next.hr],
          temp: [...h.temp.slice(-19), next.temp],
          hrv: [...h.hrv.slice(-19), next.hrv],
        }));
        return next;
      });
    }, 1500);
    return () => clearInterval(id);
  }, [crisisPhase]);

  // Countdown during alerting
  useEffect(() => {
    if (crisisPhase !== "alerting") return undefined;
    setCountdown(15);
    const id = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(id);
          return 0;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [crisisPhase]);

  useEffect(() => {
    if (crisisPhase === "alerting" && countdown === 0) {
      triggerHelp();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countdown, crisisPhase]);

  // Recovery ramp back to baseline
  useEffect(() => {
    if (crisisPhase !== "recovering") return undefined;
    const totalSteps = 14;
    const stepMs = 400;
    const start = { ...vitals };
    let step = 0;
    const id = setInterval(() => {
      step += 1;
      const t = clamp(step / totalSteps, 0, 1);
      const next = {
        spo2: clamp(start.spo2 + (BASELINE.spo2 - start.spo2) * t + jitter(0.2), 85, 99),
        hr: clamp(start.hr + (BASELINE.hr - start.hr) * t + jitter(1.5), 65, 140),
        temp: clamp(start.temp + (BASELINE.temp - start.temp) * t + jitter(0.05), 98, 102),
        hrv: clamp(start.hrv + (BASELINE.hrv - start.hrv) * t + jitter(1.5), 20, 65),
      };
      pushReading(next);
      if (step >= totalSteps) {
        clearInterval(id);
        setCrisisPhase("idle");
      }
    }, stepMs);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [crisisPhase]);

  const startSimulation = useCallback(() => {
    if (phaseRef.current !== "idle") return;
    setCrisisPhase("ramping");
    setCascadeDone([]);
  }, []);

  const dismissAlert = useCallback(() => {
    setCrisisPhase("recovering");
  }, []);

  const triggerHelp = useCallback(() => {
    setCrisisPhase((p) => (p === "alerting" ? "cascading" : p));
    setCrisisEverTriggered(true);
    setCascadeDone([]);
    CASCADE_STEPS.forEach((s, i) => {
      setTimeout(() => {
        setCascadeDone((d) => [...d, s.key]);
      }, (i + 1) * 900);
    });
    setTimeout(() => {
      setTab("crisis");
      setCrisisPhase("recovering");
    }, CASCADE_STEPS.length * 900 + 900);
  }, []);

  const addLogEntry = useCallback((entry) => {
    setLog((l) => [entry, ...l]);
  }, []);

  const flashAction = useCallback((message) => {
    setActionFeedback(message);
    setTimeout(() => setActionFeedback((m) => (m === message ? null : m)), 2200);
  }, []);

  const value = {
    tab,
    setTab,
    vitals,
    history,
    crisisPhase,
    countdown,
    cascadeDone,
    cascadeSteps: CASCADE_STEPS,
    crisisEverTriggered,
    deviceConnected,
    startSimulation,
    dismissAlert,
    triggerHelp,
    log,
    addLogEntry,
    actionFeedback,
    flashAction,
  };

  return <VasoContext.Provider value={value}>{children}</VasoContext.Provider>;
}

export function useVaso() {
  const ctx = useContext(VasoContext);
  if (!ctx) throw new Error("useVaso must be used within VasoProvider");
  return ctx;
}
