export function parseWaitToMinutes(str) {
  if (!str || str === "—") return null;
  const hMatch = str.match(/(\d+)\s*h/);
  const mMatch = str.match(/(\d+)\s*m/);
  const hours = hMatch ? parseInt(hMatch[1], 10) : 0;
  const mins = mMatch ? parseInt(mMatch[1], 10) : 0;
  if (!hMatch && !mMatch) return null;
  return hours * 60 + mins;
}

export function formatMinutes(mins) {
  if (mins == null || Number.isNaN(mins)) return "—";
  if (mins < 60) return `${Math.round(mins)} min`;
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}
