import { useState } from "react";
import {
  ShieldCheck,
  AlertTriangle,
  QrCode,
  Maximize2,
  X,
  Droplets,
  HeartPulse,
  Thermometer,
  Waves,
  BadgeCheck,
} from "lucide-react";
import { useVaso, THRESHOLDS } from "../context/VasoContext";
import { patient } from "../data/mock";

function VitalChip({ icon: Icon, label, value, unit, danger }) {
  return (
    <div
      className={[
        "rounded-xl border px-3 py-2.5 flex flex-col items-center gap-0.5",
        danger ? "bg-crimson-950 border-crimson-600" : "bg-navy-900 border-navy-700",
      ].join(" ")}
    >
      <Icon size={14} className={danger ? "text-crimson-300" : "text-slate-400"} />
      <span className={["text-lg font-bold tabular-nums", danger ? "text-crimson-300" : "text-white"].join(" ")}>
        {value}
        <span className="text-[10px] font-medium text-slate-400 ml-0.5">{unit}</span>
      </span>
      <span className="text-[9px] uppercase tracking-wide text-slate-500 font-semibold">{label}</span>
    </div>
  );
}

function CareCardContent({ fullscreen }) {
  const { vitals } = useVaso();
  const spo2Danger = vitals.spo2 <= THRESHOLDS.spo2.red;
  const hrDanger = vitals.hr >= THRESHOLDS.hr.red;
  const tempDanger = vitals.temp >= THRESHOLDS.temp.red;
  const hrvDanger = vitals.hrv <= THRESHOLDS.hrv.red;

  return (
    <div className={fullscreen ? "max-w-[440px] mx-auto w-full" : ""}>
      <div className="rounded-3xl bg-navy-800 border-2 border-crimson-600/60 overflow-hidden shadow-xl shadow-black/40">
        <div className="bg-gradient-to-r from-crimson-700 to-crimson-600 px-5 py-4 flex items-center gap-3">
          <ShieldCheck size={26} className="text-white shrink-0" strokeWidth={2.5} />
          <div>
            <h1 className="text-white font-extrabold text-sm tracking-wide leading-tight">
              VERIFIED INDIVIDUALIZED CARE PLAN
            </h1>
            <p className="text-crimson-100 text-[11px] font-medium mt-0.5">
              {patient.name} · {patient.age} · {patient.genotype} · Vaso-Occlusive Crisis Protocol
            </p>
          </div>
        </div>

        <div className="p-5 flex flex-col gap-4">
          <div className="rounded-2xl bg-navy-900 border border-navy-600 p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-crimson-400 mb-1.5">
              Analgesia Protocol
            </p>
            <p className="text-sm text-white font-semibold leading-relaxed">
              INDIVIDUALIZED ANALGESIA PROTOCOL ON FILE — {patient.hematologist}, MD, Hematology, Johns
              Hopkins.
            </p>
            <p className="text-xs text-sky-300 font-bold mt-2">Verify: {patient.hematologistPhone}</p>
          </div>

          <div className="rounded-2xl bg-crimson-950 border-2 border-crimson-500 p-4 flex gap-3">
            <AlertTriangle size={22} className="text-crimson-300 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-extrabold text-crimson-100 leading-snug">
                ACUTE CHEST SYNDROME RISK — {patient.priorACS} prior episodes
              </p>
              <p className="text-xs text-crimson-200/80 mt-1">Check SpO2 and chest X-ray.</p>
            </div>
          </div>

          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">
              Live vitals · Vaso Band
            </p>
            <div className="grid grid-cols-4 gap-2">
              <VitalChip icon={Droplets} label="SpO2" value={vitals.spo2.toFixed(0)} unit="%" danger={spo2Danger} />
              <VitalChip icon={HeartPulse} label="HR" value={vitals.hr.toFixed(0)} unit="bpm" danger={hrDanger} />
              <VitalChip
                icon={Thermometer}
                label="Temp"
                value={vitals.temp.toFixed(1)}
                unit="°F"
                danger={tempDanger}
              />
              <VitalChip icon={Waves} label="HRV" value={vitals.hrv.toFixed(0)} unit="ms" danger={hrvDanger} />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-xl bg-white/95 flex items-center justify-center shrink-0 relative overflow-hidden">
              <QrCode size={56} className="text-navy-950" strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-xs font-bold text-white">Scan for full record</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Full history, medication list, and hematology notes.
              </p>
            </div>
          </div>

          <div className="border-t border-navy-600 pt-3">
            <p className="text-[10px] text-slate-500 leading-relaxed">
              ASH 2020 Guidelines recommend analgesia within 60 minutes and use of individualized pain
              plans. CDC 2022 Opioid Guideline explicitly excludes sickle cell disease.
            </p>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <BadgeCheck size={15} />
              <span className="text-[11px] font-bold">Signed 2026-03-14 · NPI verified</span>
            </div>
            <span className="text-[10px] text-slate-500 font-medium">{patient.insurance}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Card() {
  const [fullscreen, setFullscreen] = useState(false);

  if (fullscreen) {
    return (
      <div className="fixed inset-0 z-50 bg-navy-950 overflow-y-auto p-5">
        <button
          onClick={() => setFullscreen(false)}
          className="fixed top-4 right-4 z-10 w-10 h-10 rounded-full bg-navy-800 border border-navy-600 flex items-center justify-center text-white active:scale-95"
        >
          <X size={18} />
        </button>
        <div className="pt-2 pb-8">
          <CareCardContent fullscreen />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 pb-4">
      <CareCardContent />
      <button
        onClick={() => setFullscreen(true)}
        className="w-full flex items-center justify-center gap-2 rounded-2xl bg-navy-800 border border-navy-600 py-3.5 font-bold text-sm text-white hover:bg-navy-700 active:scale-[0.98] transition"
      >
        <Maximize2 size={17} />
        Fullscreen for ER staff
      </button>
    </div>
  );
}
