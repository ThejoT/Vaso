import { AlertTriangle, CalendarDays, Clock, Download, Gauge, MapPin, Stethoscope } from "lucide-react";
import { useVaso } from "../context/VasoContext";
import { patient } from "../data/mock";
import { formatMinutes, parseWaitToMinutes } from "../utils/format";

function StatCard({ icon: Icon, label, value }) {
  return (
    <div className="rounded-2xl bg-navy-800 border border-navy-700 p-3.5 flex flex-col gap-1.5">
      <Icon size={15} className="text-crimson-400" />
      <span className="text-xl font-extrabold text-white tabular-nums leading-none">{value}</span>
      <span className="text-[10px] uppercase tracking-wide text-slate-500 font-semibold leading-tight">
        {label}
      </span>
    </div>
  );
}

function LogEntry({ entry }) {
  return (
    <div
      className={[
        "rounded-2xl border p-4 flex flex-col gap-2.5",
        entry.flagged ? "bg-crimson-950 border-crimson-600" : "bg-navy-800 border-navy-700",
      ].join(" ")}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
          <CalendarDays size={13} />
          {entry.date}
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
          <Clock size={13} />
          {entry.duration}
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <Gauge size={14} className={entry.flagged ? "text-crimson-300" : "text-slate-400"} />
          <span className={["text-sm font-bold", entry.flagged ? "text-crimson-200" : "text-white"].join(" ")}>
            Peak pain {entry.peakPain}/10
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <MapPin size={14} className={entry.flagged ? "text-crimson-300" : "text-slate-400"} />
          <span className="text-sm text-slate-300">{entry.location}</span>
        </div>
      </div>

      <div className="flex items-center gap-1.5 text-xs text-slate-400">
        <Stethoscope size={13} />
        {entry.treatedAt} · wait before analgesia: {entry.waitBeforeAnalgesia}
      </div>

      <div
        className={[
          "text-xs font-semibold rounded-lg px-3 py-2 flex items-start gap-2",
          entry.flagged
            ? "bg-crimson-900/60 text-crimson-200"
            : "bg-navy-900 text-slate-300",
        ].join(" ")}
      >
        {entry.flagged && <AlertTriangle size={14} className="shrink-0 mt-0.5" />}
        {entry.outcome}
      </div>
    </div>
  );
}

export default function Log() {
  const { log } = useVaso();

  const currentYear = new Date().getFullYear().toString();
  const crisesThisYear = log.filter((e) => e.date.startsWith(currentYear)).length;

  const edWaits = log
    .filter((e) => e.treatedAt.toLowerCase().includes("emergency"))
    .map((e) => parseWaitToMinutes(e.waitBeforeAnalgesia))
    .filter((v) => v != null);
  const avgEdWait = edWaits.length ? edWaits.reduce((a, b) => a + b, 0) / edWaits.length : null;

  const infusionWaits = log
    .filter((e) => e.treatedAt.toLowerCase().includes("infusion"))
    .map((e) => parseWaitToMinutes(e.waitBeforeAnalgesia))
    .filter((v) => v != null);
  const avgInfusionWait = infusionWaits.length
    ? infusionWaits.reduce((a, b) => a + b, 0) / infusionWaits.length
    : null;

  const handleExport = () => {
    const lines = [
      `Vaso Crisis Report — ${patient.name}`,
      `Generated ${new Date().toISOString().slice(0, 10)} for ${patient.hematologist}`,
      `Patient: ${patient.name}, ${patient.age}, ${patient.genotype}`,
      "",
      `Crises this year: ${crisesThisYear}`,
      `Average ED wait before analgesia: ${formatMinutes(avgEdWait)}`,
      `Average infusion center wait before analgesia: ${formatMinutes(avgInfusionWait)}`,
      "",
      "Crisis history:",
      ...log.map(
        (e, i) =>
          `${i + 1}. ${e.date} — duration ${e.duration}, peak pain ${e.peakPain}/10, location: ${e.location}, treated at ${e.treatedAt}, wait before analgesia: ${e.waitBeforeAnalgesia}. Outcome: ${e.outcome}`
      ),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vaso-crisis-report-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-4 pb-4">
      <div>
        <h1 className="text-lg font-bold text-white">Crisis Log</h1>
        <p className="text-xs text-slate-400">Chronological history for {patient.name}</p>
      </div>

      <div className="grid grid-cols-3 gap-2.5">
        <StatCard icon={CalendarDays} label="Crises this year" value={crisesThisYear} />
        <StatCard icon={Clock} label="Avg ED wait" value={formatMinutes(avgEdWait)} />
        <StatCard icon={Clock} label="Avg infusion wait" value={formatMinutes(avgInfusionWait)} />
      </div>

      <button
        onClick={handleExport}
        className="w-full flex items-center justify-center gap-2 rounded-2xl bg-navy-800 border border-navy-600 py-3.5 font-bold text-sm text-white hover:bg-navy-700 active:scale-[0.98] transition"
      >
        <Download size={17} />
        Export report for Dr. Ayers
      </button>

      <div className="flex flex-col gap-3">
        {log.map((entry) => (
          <LogEntry key={entry.id} entry={entry} />
        ))}
      </div>
    </div>
  );
}
