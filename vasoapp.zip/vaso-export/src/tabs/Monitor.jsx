import { Activity, Bluetooth, Droplets, HeartPulse, Siren, Thermometer, Waves } from "lucide-react";
import { useVaso, THRESHOLDS } from "../context/VasoContext";
import VitalCard from "../components/VitalCard";

export default function Monitor() {
  const { vitals, history, deviceConnected, crisisPhase, startSimulation } = useVaso();

  const spo2Danger = vitals.spo2 <= THRESHOLDS.spo2.red;
  const spo2Warn = !spo2Danger && vitals.spo2 <= THRESHOLDS.spo2.warn;
  const hrDanger = vitals.hr >= THRESHOLDS.hr.red;
  const hrWarn = !hrDanger && vitals.hr >= THRESHOLDS.hr.warn;
  const tempDanger = vitals.temp >= THRESHOLDS.temp.red;
  const tempWarn = !tempDanger && vitals.temp >= THRESHOLDS.temp.warn;
  const hrvDanger = vitals.hrv <= THRESHOLDS.hrv.red;
  const hrvWarn = !hrvDanger && vitals.hrv <= THRESHOLDS.hrv.warn;

  const simInProgress = crisisPhase !== "idle";

  return (
    <div className="flex flex-col gap-4 pb-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-white">Live Monitor</h1>
          <p className="text-xs text-slate-400">Maya Johnson · Vaso Band</p>
        </div>
        <div
          className={[
            "flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold border",
            deviceConnected
              ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-400"
              : "bg-slate-700/20 border-slate-600 text-slate-400",
          ].join(" ")}
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <Bluetooth size={12} />
          Device connected
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <VitalCard
          icon={Droplets}
          label="SpO2"
          value={vitals.spo2.toFixed(0)}
          unit="%"
          data={history.spo2}
          danger={spo2Danger}
          warn={spo2Warn}
        />
        <VitalCard
          icon={HeartPulse}
          label="Heart rate"
          value={vitals.hr.toFixed(0)}
          unit="bpm"
          data={history.hr}
          danger={hrDanger}
          warn={hrWarn}
        />
        <VitalCard
          icon={Thermometer}
          label="Skin temp"
          value={vitals.temp.toFixed(1)}
          unit="°F"
          data={history.temp}
          danger={tempDanger}
          warn={tempWarn}
        />
        <VitalCard
          icon={Waves}
          label="HRV"
          value={vitals.hrv.toFixed(0)}
          unit="ms"
          data={history.hrv}
          danger={hrvDanger}
          warn={hrvWarn}
        />
      </div>

      <div className="rounded-2xl bg-navy-800 border border-navy-700 p-4 flex items-start gap-3">
        <Activity size={18} className="text-sky-400 mt-0.5 shrink-0" />
        <p className="text-xs text-slate-400 leading-relaxed">
          Vaso Band streams SpO2, heart rate, skin temperature, and HRV every 2 seconds. Sudden drops in
          SpO2 combined with rising heart rate and temperature can indicate a vaso-occlusive or acute
          chest syndrome event.
        </p>
      </div>

      <button
        onClick={startSimulation}
        disabled={simInProgress}
        className={[
          "mt-2 w-full flex items-center justify-center gap-2 rounded-2xl py-4 font-extrabold text-base tracking-wide transition active:scale-[0.98]",
          simInProgress
            ? "bg-crimson-950 text-crimson-300/60 cursor-not-allowed border border-crimson-800"
            : "bg-crimson-600 hover:bg-crimson-500 text-white shadow-lg shadow-crimson-950/60",
        ].join(" ")}
      >
        <Siren size={20} className={simInProgress ? "animate-pulse" : ""} />
        {simInProgress ? "SIMULATION RUNNING…" : "SIMULATE CRISIS"}
      </button>
      <p className="text-center text-[10px] text-slate-500 -mt-2">
        Demo mode · simulates a vaso-occlusive crisis onset for testing
      </p>
    </div>
  );
}
