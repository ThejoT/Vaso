import { useState } from "react";
import {
  AlertOctagon,
  Ambulance,
  MessageCircle,
  Phone,
  PhoneCall,
  Syringe,
  CheckCircle2,
  ClipboardList,
} from "lucide-react";
import { useVaso } from "../context/VasoContext";
import { patient } from "../data/mock";

const LOCATIONS = [
  { id: "chest", label: "Chest" },
  { id: "back", label: "Back" },
  { id: "arms", label: "Arms" },
  { id: "legs", label: "Legs" },
  { id: "abdomen", label: "Abdomen" },
];

const ACTIONS = [
  {
    id: "ayers",
    label: "Call Dr. Ayers (hematology)",
    sub: "Johns Hopkins Sickle Cell Center",
    icon: PhoneCall,
    tone: "primary",
  },
  {
    id: "infusion",
    label: "Call infusion center",
    sub: "Johns Hopkins Sickle Cell Infusion Center",
    icon: Syringe,
    tone: "primary",
  },
  {
    id: "message",
    label: "Message care team",
    sub: "Renee Okafor, RN · usually replies in 10 min",
    icon: MessageCircle,
    tone: "secondary",
  },
  {
    id: "911",
    label: "Call 911",
    sub: "Emergency medical services",
    icon: Ambulance,
    tone: "danger",
  },
];

export default function Crisis() {
  const { flashAction, actionFeedback, addLogEntry, setTab } = useVaso();
  const [pain, setPain] = useState(null);
  const [locations, setLocations] = useState([]);
  const [logged, setLogged] = useState(false);

  const toggleLocation = (id) => {
    setLocations((locs) => (locs.includes(id) ? locs.filter((l) => l !== id) : [...locs, id]));
  };

  const handleAction = (action) => {
    const messages = {
      ayers: `Calling Dr. Ayers at ${patient.hematologistPhone}…`,
      infusion: "Calling Johns Hopkins Sickle Cell Infusion Center…",
      message: "Opening secure message to your care team…",
      911: "Calling 911 — share your location when connected.",
    };
    flashAction(messages[action.id]);
  };

  const handleLog = () => {
    if (pain === null) return;
    const locLabel = locations.length
      ? locations.map((id) => LOCATIONS.find((l) => l.id === id)?.label).join(", ")
      : "Not specified";
    addLogEntry({
      id: `log-${Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
      duration: "Ongoing",
      peakPain: pain,
      location: locLabel,
      treatedAt: "Self-reported from Crisis tab",
      waitBeforeAnalgesia: "—",
      outcome: "Logged in progress — not yet treated",
      flagged: pain >= 8,
    });
    setLogged(true);
    setTimeout(() => setLogged(false), 2500);
  };

  return (
    <div className="flex flex-col gap-4 pb-4">
      <div>
        <h1 className="text-lg font-bold text-white">Crisis Mode</h1>
        <p className="text-xs text-slate-400">Fast actions for an active vaso-occlusive crisis</p>
      </div>

      <div className="rounded-2xl bg-crimson-950 border border-crimson-600 p-4 flex gap-3">
        <AlertOctagon size={22} className="text-crimson-300 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-bold text-crimson-100 leading-snug">
            ACUTE CHEST SYNDROME RISK — {patient.priorACS} prior episodes
          </p>
          <p className="text-xs text-crimson-200/80 mt-1 leading-relaxed">
            Chest pain, fever, or breathlessness means go to the ED now.
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-2.5">
        {ACTIONS.map((action) => {
          const Icon = action.icon;
          const toneClasses =
            action.tone === "danger"
              ? "bg-crimson-600 hover:bg-crimson-500 border-crimson-500 text-white"
              : action.tone === "primary"
              ? "bg-navy-800 hover:bg-navy-700 border-navy-600 text-white"
              : "bg-navy-800 hover:bg-navy-700 border-navy-600 text-white";
          return (
            <button
              key={action.id}
              onClick={() => handleAction(action)}
              className={`w-full flex items-center gap-3 rounded-2xl border px-4 py-3.5 transition active:scale-[0.98] ${toneClasses}`}
            >
              <div
                className={[
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                  action.tone === "danger" ? "bg-white/15" : "bg-crimson-500/15",
                ].join(" ")}
              >
                <Icon size={19} className={action.tone === "danger" ? "text-white" : "text-crimson-400"} />
              </div>
              <div className="text-left">
                <div className="font-bold text-sm">{action.label}</div>
                <div className="text-[11px] opacity-70">{action.sub}</div>
              </div>
            </button>
          );
        })}
      </div>

      {actionFeedback && (
        <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 text-xs font-medium px-4 py-2.5 flex items-center gap-2 animate-rise-in">
          <Phone size={14} />
          {actionFeedback}
        </div>
      )}

      <div className="rounded-2xl bg-navy-800 border border-navy-700 p-4">
        <div className="flex items-center gap-2 mb-3">
          <ClipboardList size={16} className="text-slate-300" />
          <h2 className="text-sm font-bold text-white">Log this pain episode</h2>
        </div>

        <p className="text-xs text-slate-400 mb-2">Pain level</p>
        <div className="grid grid-cols-5 gap-2 mb-4">
          {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
            <button
              key={n}
              onClick={() => setPain(n)}
              className={[
                "aspect-square rounded-lg text-sm font-bold transition border",
                pain === n
                  ? n >= 7
                    ? "bg-crimson-600 border-crimson-500 text-white"
                    : n >= 4
                    ? "bg-amber-600 border-amber-500 text-white"
                    : "bg-emerald-600 border-emerald-500 text-white"
                  : "bg-navy-900 border-navy-700 text-slate-300 hover:border-navy-500",
              ].join(" ")}
            >
              {n}
            </button>
          ))}
        </div>

        <p className="text-xs text-slate-400 mb-2">Location</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {LOCATIONS.map((loc) => (
            <button
              key={loc.id}
              onClick={() => toggleLocation(loc.id)}
              className={[
                "px-3.5 py-2 rounded-full text-xs font-semibold border transition",
                locations.includes(loc.id)
                  ? "bg-crimson-500/20 border-crimson-500 text-crimson-300"
                  : "bg-navy-900 border-navy-700 text-slate-400 hover:border-navy-500",
              ].join(" ")}
            >
              {loc.label}
            </button>
          ))}
        </div>

        <button
          onClick={handleLog}
          disabled={pain === null}
          className={[
            "w-full rounded-xl py-3 font-bold text-sm transition active:scale-[0.98]",
            pain === null
              ? "bg-navy-700 text-slate-500 cursor-not-allowed"
              : "bg-crimson-600 hover:bg-crimson-500 text-white",
          ].join(" ")}
        >
          {logged ? (
            <span className="flex items-center justify-center gap-2">
              <CheckCircle2 size={16} /> Logged to your crisis history
            </span>
          ) : (
            "Log entry"
          )}
        </button>
      </div>
    </div>
  );
}
