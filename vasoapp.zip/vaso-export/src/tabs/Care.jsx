import { MapPin, Zap, Phone, MessageCircle, ShieldCheck, Landmark } from "lucide-react";
import { useVaso } from "../context/VasoContext";
import { careTeam, facilities, insurance, patient } from "../data/mock";

function FacilityCard({ facility }) {
  const isOpen = facility.status.startsWith("OPEN");
  return (
    <div className="rounded-2xl bg-navy-800 border border-navy-700 p-4">
      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="text-sm font-bold text-white leading-snug">{facility.name}</h3>
        <span
          className={[
            "shrink-0 text-[10px] font-bold uppercase tracking-wide rounded-full px-2 py-0.5",
            isOpen ? "bg-emerald-500/15 text-emerald-400" : "bg-slate-600/20 text-slate-400",
          ].join(" ")}
        >
          {facility.status}
        </span>
      </div>
      <div className="flex items-center gap-3 text-xs text-slate-400 mb-2">
        <span className="flex items-center gap-1">
          <MapPin size={12} /> {facility.distance}
        </span>
        <span>{facility.copay}</span>
      </div>
      {facility.waitLabel && (
        <div
          className={[
            "flex items-center gap-1.5 text-xs font-semibold rounded-lg px-2.5 py-1.5 w-fit",
            facility.fast ? "bg-emerald-500/10 text-emerald-400" : "bg-amber-500/10 text-amber-400",
          ].join(" ")}
        >
          <Zap size={12} />
          {facility.waitLabel}
        </div>
      )}
    </div>
  );
}

function TeamMember({ member }) {
  const { flashAction } = useVaso();
  return (
    <div className="rounded-2xl bg-navy-800 border border-navy-700 p-4 flex items-center gap-3">
      <div className="w-11 h-11 rounded-full bg-crimson-600/20 border border-crimson-600/40 flex items-center justify-center text-crimson-300 font-bold text-sm shrink-0">
        {member.initials}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold text-white truncate">{member.name}</p>
        <p className="text-[11px] text-slate-400 truncate">{member.role}</p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => flashAction(`Calling ${member.name} at ${member.phone}…`)}
          className="w-9 h-9 rounded-full bg-navy-700 hover:bg-navy-600 flex items-center justify-center text-white active:scale-95 transition"
        >
          <Phone size={15} />
        </button>
        <button
          onClick={() => flashAction(`Opening message to ${member.name}…`)}
          className="w-9 h-9 rounded-full bg-navy-700 hover:bg-navy-600 flex items-center justify-center text-white active:scale-95 transition"
        >
          <MessageCircle size={15} />
        </button>
      </div>
    </div>
  );
}

export default function Care() {
  const { actionFeedback } = useVaso();
  const pct = Math.round((insurance.deductibleUsed / insurance.deductibleTotal) * 100);

  return (
    <div className="flex flex-col gap-6 pb-4">
      <div>
        <h1 className="text-lg font-bold text-white">Care</h1>
        <p className="text-xs text-slate-400">Facilities, your team, and coverage</p>
      </div>

      {actionFeedback && (
        <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 text-xs font-medium px-4 py-2.5 flex items-center gap-2 animate-rise-in -mt-2">
          <Phone size={14} />
          {actionFeedback}
        </div>
      )}

      <section className="flex flex-col gap-3">
        <h2 className="text-sm font-bold text-slate-200">Covered near you (Aetna PPO)</h2>
        <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/30 px-4 py-3 flex gap-2.5">
          <Zap size={16} className="text-emerald-400 shrink-0 mt-0.5" />
          <p className="text-xs text-emerald-300 leading-relaxed font-medium">
            Infusion centers get you pain relief 4x faster than the ER and are covered under your plan.
          </p>
        </div>
        <div className="flex flex-col gap-3">
          {facilities.map((f) => (
            <FacilityCard key={f.id} facility={f} />
          ))}
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-sm font-bold text-slate-200">Your care team</h2>
        <div className="flex flex-col gap-3">
          {careTeam.map((m) => (
            <TeamMember key={m.id} member={m} />
          ))}
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-sm font-bold text-slate-200">Insurance</h2>
        <div className="rounded-2xl bg-navy-800 border border-navy-700 p-4 flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/15 flex items-center justify-center shrink-0">
              <Landmark size={18} className="text-sky-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">{insurance.plan}</p>
              <p className="text-[11px] text-slate-400">Member ID {patient.memberId}</p>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs text-slate-400 font-medium">Deductible progress</span>
              <span className="text-xs text-white font-bold">
                ${insurance.deductibleUsed.toLocaleString()} of ${insurance.deductibleTotal.toLocaleString()}
              </span>
            </div>
            <div className="h-2.5 w-full rounded-full bg-navy-900 overflow-hidden">
              <div className="h-full rounded-full bg-sky-500" style={{ width: `${pct}%` }} />
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 px-3.5 py-2.5">
            <ShieldCheck size={16} className="text-emerald-400 shrink-0" />
            <span className="text-xs font-semibold text-emerald-300">{insurance.priorAuth.label}</span>
          </div>
        </div>
      </section>
    </div>
  );
}
