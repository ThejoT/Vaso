import { Activity, Siren, IdCard, HeartHandshake, ClipboardList } from "lucide-react";
import { useVaso } from "../context/VasoContext";

const TABS = [
  { id: "monitor", label: "Monitor", icon: Activity },
  { id: "crisis", label: "Crisis", icon: Siren },
  { id: "card", label: "Card", icon: IdCard },
  { id: "care", label: "Care", icon: HeartHandshake },
  { id: "log", label: "Log", icon: ClipboardList },
];

export default function BottomNav() {
  const { tab, setTab } = useVaso();

  return (
    <nav className="flex items-stretch border-t border-navy-700 bg-navy-900/95 backdrop-blur pb-[env(safe-area-inset-bottom)]">
      {TABS.map((t) => {
        const Icon = t.icon;
        const active = tab === t.id;
        return (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="flex-1 flex flex-col items-center justify-center gap-1 py-2.5 relative"
          >
            {active && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-crimson-500" />
            )}
            <Icon
              size={20}
              strokeWidth={active ? 2.5 : 2}
              className={active ? "text-crimson-400" : "text-slate-500"}
            />
            <span
              className={[
                "text-[10px] font-semibold",
                active ? "text-crimson-400" : "text-slate-500",
              ].join(" ")}
            >
              {t.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
