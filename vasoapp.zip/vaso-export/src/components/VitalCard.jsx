import Sparkline from "./Sparkline";

export default function VitalCard({ icon: Icon, label, value, unit, data, danger, warn }) {
  return (
    <div
      className={[
        "rounded-2xl p-4 border transition-colors duration-500",
        danger
          ? "bg-crimson-950 border-crimson-600 animate-flash-red"
          : warn
          ? "bg-navy-800 border-amber-500/50"
          : "bg-navy-800 border-navy-700",
      ].join(" ")}
    >
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-1.5">
          <Icon size={15} strokeWidth={2.25} className={danger ? "text-crimson-300" : "text-slate-400"} />
          <span className="text-[11px] font-medium uppercase tracking-wide text-slate-400">{label}</span>
        </div>
        {danger && (
          <span className="text-[10px] font-bold uppercase tracking-wide text-crimson-300">Alert</span>
        )}
      </div>
      <div className="flex items-end justify-between gap-2">
        <div className="flex items-baseline gap-1">
          <span className={["text-3xl font-bold tabular-nums", danger ? "text-crimson-300" : "text-white"].join(" ")}>
            {value}
          </span>
          <span className="text-sm text-slate-400 font-medium">{unit}</span>
        </div>
        <Sparkline data={data} danger={danger} warn={warn} />
      </div>
    </div>
  );
}
