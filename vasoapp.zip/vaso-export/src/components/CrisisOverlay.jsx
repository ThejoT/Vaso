import { AlertTriangle, CheckCircle2, PhoneCall, ShieldCheck, Loader2 } from "lucide-react";
import { useVaso } from "../context/VasoContext";

export default function CrisisOverlay() {
  const { crisisPhase, countdown, dismissAlert, triggerHelp, cascadeSteps, cascadeDone } = useVaso();

  if (crisisPhase !== "alerting" && crisisPhase !== "cascading") return null;

  const isCascading = crisisPhase === "cascading";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm px-4">
      <div className="w-full max-w-[400px] mx-auto">
        <div className="rounded-3xl bg-gradient-to-b from-crimson-900 to-navy-950 border border-crimson-600 shadow-2xl shadow-crimson-950/50 overflow-hidden animate-scale-in">
          {!isCascading ? (
            <div className="p-6 text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-crimson-600/20 border-2 border-crimson-500 flex items-center justify-center mb-4 animate-pulse-slow">
                <AlertTriangle size={32} className="text-crimson-300" strokeWidth={2.5} />
              </div>
              <h1 className="text-xl font-extrabold text-white leading-tight tracking-tight mb-2">
                POSSIBLE VASO-OCCLUSIVE
                <br />
                CRISIS DETECTED
              </h1>
              <p className="text-sm text-crimson-100/80 mb-5">
                Your vitals show signs consistent with an acute pain crisis. Are you okay?
              </p>

              <div className="mb-5">
                <div className="text-5xl font-black text-white tabular-nums mb-1">{countdown}</div>
                <div className="text-[11px] uppercase tracking-widest text-crimson-200/70 font-semibold">
                  seconds until care team is auto-notified
                </div>
                <div className="mt-3 h-1.5 w-full rounded-full bg-crimson-950 overflow-hidden">
                  <div
                    className="h-full bg-crimson-400 transition-all duration-1000 ease-linear"
                    style={{ width: `${(countdown / 15) * 100}%` }}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2.5">
                <button
                  onClick={triggerHelp}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-crimson-500 hover:bg-crimson-400 active:scale-[0.98] text-white font-bold text-base py-3.5 transition"
                >
                  <PhoneCall size={18} />
                  Get help now
                </button>
                <button
                  onClick={dismissAlert}
                  className="w-full rounded-xl border border-white/20 text-white/90 font-semibold text-sm py-3 hover:bg-white/5 active:scale-[0.98] transition"
                >
                  I&apos;m okay, dismiss
                </button>
              </div>
            </div>
          ) : (
            <div className="p-6">
              <div className="flex items-center gap-2 mb-5">
                <Loader2 size={20} className="text-crimson-300 animate-spin" />
                <h2 className="text-base font-bold text-white">Getting you help</h2>
              </div>
              <div className="flex flex-col gap-3">
                {cascadeSteps.map((step) => {
                  const done = cascadeDone.includes(step.key);
                  return (
                    <div
                      key={step.key}
                      className={[
                        "flex items-center gap-3 rounded-xl border px-4 py-3 transition-all duration-500",
                        done
                          ? "bg-navy-800/80 border-emerald-500/40 opacity-100 translate-x-0"
                          : "bg-navy-900/40 border-navy-700 opacity-40",
                      ].join(" ")}
                    >
                      {done ? (
                        step.key === "card" ? (
                          <ShieldCheck size={20} className="text-emerald-400 shrink-0" />
                        ) : (
                          <CheckCircle2 size={20} className="text-emerald-400 shrink-0" />
                        )
                      ) : (
                        <div className="w-5 h-5 rounded-full border-2 border-navy-600 shrink-0" />
                      )}
                      <span className={["text-sm font-medium", done ? "text-white" : "text-slate-500"].join(" ")}>
                        {step.text}
                      </span>
                    </div>
                  );
                })}
              </div>
              <p className="text-center text-[11px] text-crimson-200/60 mt-5">
                Opening Crisis Mode…
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
