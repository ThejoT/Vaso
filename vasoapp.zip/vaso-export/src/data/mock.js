export const patient = {
  name: "Maya Johnson",
  age: 24,
  genotype: "HbSS",
  baselineSpo2: 97,
  hematologist: "Dr. Amara Ayers",
  hematologistPhone: "(410) 555-0142",
  clinic: "Johns Hopkins Sickle Cell Center",
  insurance: "Aetna PPO",
  memberId: "AET-882910473",
  priorACS: 2,
  emergencyContact: { name: "Denise Johnson", relation: "Mother", phone: "(410) 555-0198" },
};

export const careTeam = [
  {
    id: "ayers",
    name: "Dr. Amara Ayers",
    role: "Hematologist · Johns Hopkins",
    phone: "(410) 555-0142",
    initials: "AA",
  },
  {
    id: "coordinator",
    name: "Renee Okafor, RN",
    role: "Nurse Care Coordinator",
    phone: "(410) 555-0176",
    initials: "RO",
  },
  {
    id: "denise",
    name: "Denise Johnson",
    role: "Emergency Contact · Mother",
    phone: "(410) 555-0198",
    initials: "DJ",
  },
];

export const facilities = [
  {
    id: "hopkins-infusion",
    name: "Johns Hopkins Sickle Cell Infusion Center",
    status: "OPEN",
    distance: "2.1 mi",
    copay: "$40 copay",
    waitLabel: "avg 22 min to pain relief",
    fast: true,
  },
  {
    id: "baltimore-community",
    name: "Baltimore Community Infusion",
    status: "CLOSED",
    distance: "5.4 mi",
    copay: "$40 copay",
    waitLabel: null,
    fast: true,
  },
  {
    id: "hopkins-ed",
    name: "Hopkins Emergency Dept",
    status: "OPEN 24/7",
    distance: "2.3 mi",
    copay: "$350 copay",
    waitLabel: "avg 94 min to pain relief",
    fast: false,
  },
];

export const insurance = {
  plan: "Aetna PPO",
  memberId: "AET-882910473",
  deductibleUsed: 1240,
  deductibleTotal: 2500,
  priorAuth: {
    label: "VOC protocol — APPROVED through Dec 2026",
    status: "approved",
  },
};

export const initialLog = [
  {
    id: "log-1",
    date: "2026-06-02",
    duration: "2h 10m",
    peakPain: 8,
    location: "Chest, back",
    treatedAt: "Johns Hopkins Sickle Cell Infusion Center",
    waitBeforeAnalgesia: "24 min",
    outcome: "Resolved, discharged home",
    flagged: false,
  },
  {
    id: "log-2",
    date: "2026-04-19",
    duration: "4h 55m",
    peakPain: 9,
    location: "Legs, arms",
    treatedAt: "Hopkins Emergency Dept",
    waitBeforeAnalgesia: "4h 20m",
    outcome: "ED visit — 4h 20m before first analgesia",
    flagged: true,
  },
  {
    id: "log-3",
    date: "2026-02-08",
    duration: "1h 40m",
    peakPain: 6,
    location: "Back",
    treatedAt: "Johns Hopkins Sickle Cell Infusion Center",
    waitBeforeAnalgesia: "19 min",
    outcome: "Resolved, discharged home",
    flagged: false,
  },
  {
    id: "log-4",
    date: "2025-12-27",
    duration: "3h 05m",
    peakPain: 7,
    location: "Abdomen, chest",
    treatedAt: "Johns Hopkins Sickle Cell Infusion Center",
    waitBeforeAnalgesia: "31 min",
    outcome: "Resolved, admitted for observation",
    flagged: false,
  },
];
